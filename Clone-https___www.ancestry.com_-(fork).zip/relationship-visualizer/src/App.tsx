import { useState, useEffect, useCallback } from 'react';
import { FaPlus } from 'react-icons/fa';
import Layout from './components/Layout';
import RelationshipGraph from './components/RelationshipGraph';
import Modal from './components/Modal';
import NodeForm from './components/NodeForm';
import RelationshipForm from './components/RelationshipForm';
import DataControls from './components/DataControls';
import LayoutControls from './components/LayoutControls';
import StatisticsPanel from './components/StatisticsPanel';
import CategoryManager from './components/CategoryManager';
import { sampleData } from './data/sampleData';
import { GraphData, RelationshipType, Node, Relationship, LayoutType } from './types';
import { saveData, loadData, hasStoredData } from './services/storageService';

function App() {
  // Main data state
  const [data, setData] = useState<GraphData>(sampleData);
  const [filteredData, setFilteredData] = useState<GraphData>(sampleData);

  // UI state
  const [searchQuery, setSearchQuery] = useState('');
  const [relationshipFilter, setRelationshipFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [layoutType, setLayoutType] = useState<LayoutType>('force-directed');
  const [showStats, setShowStats] = useState(false);

  // Modal state for adding/editing entities
  const [isNodeModalOpen, setIsNodeModalOpen] = useState(false);
  const [isRelationshipModalOpen, setIsRelationshipModalOpen] = useState(false);
  const [editingNode, setEditingNode] = useState<Node | undefined>(undefined);
  const [editingRelationship, setEditingRelationship] = useState<Relationship | undefined>(undefined);

  // Load data from localStorage on initial render
  useEffect(() => {
    const storedData = loadData();
    if (storedData) {
      setData(storedData);
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    saveData(data);
  }, [data]);

  // Memoize the filter function to avoid dependency issues
  const applyFilters = useCallback((query: string, relFilter: string, catFilter: string | null) => {
    let filteredNodes = [...data.nodes];
    let filteredRelationships = [...data.relationships];

    // Apply search filter
    if (query) {
      const lowerQuery = query.toLowerCase();
      filteredNodes = filteredNodes.filter(node =>
        node.name.toLowerCase().includes(lowerQuery) ||
        (node.type === 'person' && node.title?.toLowerCase().includes(lowerQuery)) ||
        (node.type === 'company' && node.industry?.toLowerCase().includes(lowerQuery))
      );

      // Get IDs of filtered nodes
      const nodeIds = new Set(filteredNodes.map(node => node.id));

      // Keep relationships where both source and target are in filtered nodes
      filteredRelationships = filteredRelationships.filter(rel =>
        nodeIds.has(rel.source) && nodeIds.has(rel.target)
      );
    }

    // Apply relationship filter
    if (relFilter !== 'all') {
      filteredRelationships = filteredRelationships.filter(rel =>
        rel.type === relFilter as RelationshipType
      );

      // Get all nodes involved in the filtered relationships
      const nodeIds = new Set<string>();
      filteredRelationships.forEach(rel => {
        nodeIds.add(rel.source);
        nodeIds.add(rel.target);
      });

      // Keep only nodes that are in the filtered relationships
      filteredNodes = filteredNodes.filter(node => nodeIds.has(node.id));
    }

    // Apply category filter
    if (catFilter) {
      filteredNodes = filteredNodes.filter(node => node.category === catFilter);

      // Get IDs of filtered nodes
      const nodeIds = new Set(filteredNodes.map(node => node.id));

      // Keep relationships where both source and target are in filtered nodes
      filteredRelationships = filteredRelationships.filter(rel =>
        nodeIds.has(rel.source) && nodeIds.has(rel.target)
      );
    }

    setFilteredData({
      nodes: filteredNodes,
      relationships: filteredRelationships
    });
  }, [data]);

  // Update filtered data whenever filters change
  useEffect(() => {
    applyFilters(searchQuery, relationshipFilter, categoryFilter);
  }, [applyFilters, searchQuery, relationshipFilter, categoryFilter]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleFilterChange = (filter: string) => {
    setRelationshipFilter(filter);
  };

  const handleCategoryFilter = (category: string | null) => {
    setCategoryFilter(category);
  };

  const handleLayoutChange = (layout: LayoutType) => {
    setLayoutType(layout);
  };

  // Handle node selection for editing
  const handleNodeSelect = (nodeId: string) => {
    const node = data.nodes.find(n => n.id === nodeId);
    if (node) {
      setEditingNode(node);
      setIsNodeModalOpen(true);
    }
  };

  // Handle relationship selection for editing
  const handleRelationshipSelect = (sourceId: string, targetId: string) => {
    const relationship = data.relationships.find(
      r => r.source === sourceId && r.target === targetId
    );
    if (relationship) {
      setEditingRelationship(relationship);
      setIsRelationshipModalOpen(true);
    }
  };

  // Update a node's category
  const handleUpdateNodeCategory = (nodeId: string, category: string) => {
    setData(prevData => {
      const updatedNodes = prevData.nodes.map(node => {
        if (node.id === nodeId) {
          return { ...node, category };
        }
        return node;
      });

      return {
        ...prevData,
        nodes: updatedNodes
      };
    });
  };

  // Save a new or updated node
  const handleSaveNode = (node: Node) => {
    setData(prevData => {
      // Check if we're updating an existing node
      const nodeIndex = prevData.nodes.findIndex(n => n.id === node.id);

      if (nodeIndex >= 0) {
        // Update existing node
        const updatedNodes = [...prevData.nodes];
        updatedNodes[nodeIndex] = node;
        return { ...prevData, nodes: updatedNodes };
      } else {
        // Add new node
        return { ...prevData, nodes: [...prevData.nodes, node] };
      }
    });

    setIsNodeModalOpen(false);
    setEditingNode(undefined);
  };

  // Delete a node and all its relationships
  const handleDeleteNode = (nodeId: string) => {
    setData(prevData => {
      // Remove the node
      const updatedNodes = prevData.nodes.filter(n => n.id !== nodeId);

      // Remove any relationships involving this node
      const updatedRelationships = prevData.relationships.filter(
        r => r.source !== nodeId && r.target !== nodeId
      );

      return {
        nodes: updatedNodes,
        relationships: updatedRelationships
      };
    });

    setIsNodeModalOpen(false);
    setEditingNode(undefined);
  };

  // Save a new or updated relationship
  const handleSaveRelationship = (relationship: Relationship) => {
    setData(prevData => {
      // Check if we're updating an existing relationship
      const relationshipIndex = prevData.relationships.findIndex(
        r => r.source === relationship.source && r.target === relationship.target
      );

      if (relationshipIndex >= 0) {
        // Update existing relationship
        const updatedRelationships = [...prevData.relationships];
        updatedRelationships[relationshipIndex] = relationship;
        return { ...prevData, relationships: updatedRelationships };
      } else {
        // Add new relationship
        return { ...prevData, relationships: [...prevData.relationships, relationship] };
      }
    });

    setIsRelationshipModalOpen(false);
    setEditingRelationship(undefined);
  };

  // Delete a relationship
  const handleDeleteRelationship = (source: string, target: string) => {
    setData(prevData => {
      const updatedRelationships = prevData.relationships.filter(
        r => !(r.source === source && r.target === target)
      );

      return {
        ...prevData,
        relationships: updatedRelationships
      };
    });

    setIsRelationshipModalOpen(false);
    setEditingRelationship(undefined);
  };

  // Functions to open modals for creating new entities
  const openAddNodeModal = () => {
    setEditingNode(undefined);
    setIsNodeModalOpen(true);
  };

  const openAddRelationshipModal = () => {
    setEditingRelationship(undefined);
    setIsRelationshipModalOpen(true);
  };

  // Reset data to sample data
  const handleResetData = () => {
    setData(sampleData);
    setCategoryFilter(null);
  };

  // Import data from JSON file
  const handleImportData = (importedData: GraphData) => {
    setData(importedData);
    setCategoryFilter(null);
  };

  return (
    <Layout
      title="Corporate Relationship Visualization"
      onSearch={handleSearch}
      onFilterChange={handleFilterChange}
    >
      <div className="bg-white rounded-lg shadow-lg p-4 h-[calc(100vh-12rem)] relative">
        <RelationshipGraph
          data={filteredData}
          width={800}
          height={600}
          layout={layoutType}
          onNodeSelect={handleNodeSelect}
          onRelationshipSelect={handleRelationshipSelect}
        />

        {/* Data controls in top */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-start">
          <DataControls
            data={data}
            onReset={handleResetData}
            onImport={handleImportData}
            isPersisted={hasStoredData()}
          />

          {/* Layout controls in top-right corner */}
          <div className="absolute top-0 right-4">
            <LayoutControls
              currentLayout={layoutType}
              onLayoutChange={handleLayoutChange}
            />
          </div>
        </div>

        {/* Statistics Panel */}
        <div className="absolute bottom-6 left-6">
          <StatisticsPanel
            data={data}
            isOpen={showStats}
            onToggle={() => setShowStats(!showStats)}
          />
        </div>

        {/* Category Manager */}
        <div className="absolute bottom-24 left-6">
          <CategoryManager
            nodes={data.nodes}
            onUpdateNodeCategory={handleUpdateNodeCategory}
            onFilterByCategory={handleCategoryFilter}
          />
        </div>

        {/* Floating action buttons */}
        <div className="absolute bottom-6 right-6 flex flex-col space-y-2">
          <button
            onClick={openAddNodeModal}
            className="bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition-colors"
            title="Add Entity"
          >
            <FaPlus className="h-5 w-5" />
          </button>
          <button
            onClick={openAddRelationshipModal}
            className="bg-green-600 text-white p-3 rounded-full shadow-lg hover:bg-green-700 transition-colors"
            title="Add Relationship"
            disabled={data.nodes.length < 2}
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 11l4-4m0 0l4 4m-4-4v12" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 11l-4-4m0 0l-4 4m4-4v12" />
            </svg>
          </button>
        </div>
      </div>

      {/* Modal for adding/editing nodes */}
      <Modal
        isOpen={isNodeModalOpen}
        onClose={() => {
          setIsNodeModalOpen(false);
          setEditingNode(undefined);
        }}
        title={editingNode ? 'Edit Entity' : 'Add New Entity'}
      >
        <NodeForm
          node={editingNode}
          onSave={handleSaveNode}
          onDelete={handleDeleteNode}
          onCancel={() => {
            setIsNodeModalOpen(false);
            setEditingNode(undefined);
          }}
        />
      </Modal>

      {/* Modal for adding/editing relationships */}
      <Modal
        isOpen={isRelationshipModalOpen}
        onClose={() => {
          setIsRelationshipModalOpen(false);
          setEditingRelationship(undefined);
        }}
        title={editingRelationship ? 'Edit Relationship' : 'Add New Relationship'}
      >
        <RelationshipForm
          relationship={editingRelationship}
          nodes={data.nodes}
          onSave={handleSaveRelationship}
          onDelete={handleDeleteRelationship}
          onCancel={() => {
            setIsRelationshipModalOpen(false);
            setEditingRelationship(undefined);
          }}
        />
      </Modal>
    </Layout>
  );
}

export default App;
