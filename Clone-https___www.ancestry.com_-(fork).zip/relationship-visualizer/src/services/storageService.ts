import { GraphData } from '../types';

// Storage keys
const STORAGE_KEY = 'relationship-visualizer-data';

/**
 * Save graph data to localStorage
 */
export const saveData = (data: GraphData): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving data to localStorage:', error);
  }
};

/**
 * Load graph data from localStorage
 * Returns null if no data is found or if there's an error
 */
export const loadData = (): GraphData | null => {
  try {
    const storedData = localStorage.getItem(STORAGE_KEY);
    if (!storedData) return null;

    return JSON.parse(storedData) as GraphData;
  } catch (error) {
    console.error('Error loading data from localStorage:', error);
    return null;
  }
};

/**
 * Clear all stored graph data from localStorage
 */
export const clearData = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error('Error clearing data from localStorage:', error);
  }
};

/**
 * Check if there is any stored data in localStorage
 */
export const hasStoredData = (): boolean => {
  try {
    return localStorage.getItem(STORAGE_KEY) !== null;
  } catch {
    return false;
  }
};
