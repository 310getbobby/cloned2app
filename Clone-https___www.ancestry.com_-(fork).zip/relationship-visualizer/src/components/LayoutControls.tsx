import { useState } from 'react';
import { LayoutType } from '../types';
import {
  FaProjectDiagram,
  FaCircle,
  FaSitemap,
  FaDotCircle,
  FaInfoCircle
} from 'react-icons/fa';

interface LayoutControlsProps {
  currentLayout: LayoutType;
  onLayoutChange: (layout: LayoutType) => void;
}

export default function LayoutControls({ currentLayout, onLayoutChange }: LayoutControlsProps) {
  const [showInfo, setShowInfo] = useState(false);

  const layouts: { type: LayoutType; label: string; icon: JSX.Element; description: string }[] = [
    {
      type: 'force-directed',
      label: 'Force-Directed',
      icon: <FaProjectDiagram />,
      description: 'A physics-based layout that naturally distributes nodes based on their connections.'
    },
    {
      type: 'circular',
      label: 'Circular',
      icon: <FaCircle />,
      description: 'Arranges nodes in a circle, useful for showing cyclical relationships.'
    },
    {
      type: 'hierarchical',
      label: 'Hierarchical',
      icon: <FaSitemap />,
      description: 'Arranges nodes in a top-down hierarchy based on their connections.'
    },
    {
      type: 'radial',
      label: 'Radial',
      icon: <FaDotCircle />,
      description: 'Places the most connected node at the center with others radiating outwards.'
    }
  ];

  return (
    <div className="layout-controls bg-white rounded-md shadow-md p-2">
      <div className="flex items-center mb-2">
        <h3 className="text-sm font-medium text-gray-700 mr-2">Layout</h3>
        <button
          onClick={() => setShowInfo(!showInfo)}
          className="text-gray-400 hover:text-gray-600"
          title="Layout information"
        >
          <FaInfoCircle className="h-4 w-4" />
        </button>
      </div>

      {showInfo && (
        <div className="mb-3 p-2 bg-blue-50 text-blue-800 text-xs rounded">
          <p className="mb-1">Different layouts help visualize relationships in various ways:</p>
          <ul className="list-disc pl-4 space-y-1">
            {layouts.map(layout => (
              <li key={layout.type}>
                <strong>{layout.label}:</strong> {layout.description}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="grid grid-cols-2 gap-2">
        {layouts.map(layout => (
          <button
            key={layout.type}
            onClick={() => onLayoutChange(layout.type)}
            className={`flex items-center px-3 py-2 rounded text-sm ${
              currentLayout === layout.type
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
            title={layout.description}
          >
            <span className="mr-2">{layout.icon}</span>
            <span>{layout.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
