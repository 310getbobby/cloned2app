import { useState, useEffect } from 'react';
import { FaTrash } from 'react-icons/fa';
import { Node, Relationship, RelationshipType } from '../types';

interface RelationshipFormProps {
  relationship?: Relationship;
  nodes: Node[];
  onSave: (relationship: Relationship) => void;
  onDelete?: (source: string, target: string) => void;
  onCancel: () => void;
}

export default function RelationshipForm({
  relationship,
  nodes,
  onSave,
  onDelete,
  onCancel
}: RelationshipFormProps) {
  const [source, setSource] = useState(relationship?.source || '');
  const [target, setTarget] = useState(relationship?.target || '');
  const [type, setType] = useState<RelationshipType>(relationship?.type || 'employment');
  const [year, setYear] = useState(relationship?.year?.toString() || '');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Optional details fields
  const [details, setDetails] = useState<Record<string, string>>({});

  // Update form when relationship changes
  useEffect(() => {
    if (relationship) {
      setSource(relationship.source);
      setTarget(relationship.target);
      setType(relationship.type);
      setYear(relationship.year?.toString() || '');

      // Convert details object to string values for form
      const detailsObject: Record<string, string> = {};
      if (relationship.details) {
        Object.entries(relationship.details).forEach(([key, value]) => {
          detailsObject[key] = value?.toString() || '';
        });
      }
      setDetails(detailsObject);
    }
  }, [relationship]);

  // Handle adding a new detail field
  const addDetailField = () => {
    setDetails({ ...details, [''] : '' });
  };

  // Handle removing a detail field
  const removeDetailField = (key: string) => {
    const newDetails = { ...details };
    delete newDetails[key];
    setDetails(newDetails);
  };

  // Handle updating a detail key
  const updateDetailKey = (oldKey: string, newKey: string) => {
    const newDetails = { ...details };
    const value = newDetails[oldKey];
    delete newDetails[oldKey];
    newDetails[newKey] = value;
    setDetails(newDetails);
  };

  // Handle updating a detail value
  const updateDetailValue = (key: string, value: string) => {
    setDetails({ ...details, [key]: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Create the details object with proper types
    const processedDetails: Record<string, unknown> = {};
    Object.entries(details).forEach(([key, value]) => {
      if (key && value) {
        // Try to convert numeric values
        if (!isNaN(Number(value))) {
          processedDetails[key] = Number(value);
        } else {
          processedDetails[key] = value;
        }
      }
    });

    // Create the relationship object
    const newRelationship: Relationship = {
      source,
      target,
      type,
      ...(year ? { year: parseInt(year, 10) } : {}),
      ...(Object.keys(processedDetails).length > 0 ? { details: processedDetails } : {})
    };

    onSave(newRelationship);
  };

  const handleDelete = () => {
    if (onDelete && relationship) {
      onDelete(relationship.source, relationship.target);
    }
  };

  // Get the names of the source and target nodes for display
  const getNodeName = (id: string) => {
    const node = nodes.find(n => n.id === id);
    return node ? node.name : id;
  };

  return (
    <div>
      {!showDeleteConfirm ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-4">
            <div>
              <label htmlFor="source" className="block text-sm font-medium text-gray-700 mb-1">
                Source Entity*
              </label>
              <select
                id="source"
                value={source}
                onChange={(e) => setSource(e.target.value)}
                required
                className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">Select Source</option>
                {nodes.map((node) => (
                  <option key={`source-${node.id}`} value={node.id}>
                    {node.name} ({node.type})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="target" className="block text-sm font-medium text-gray-700 mb-1">
                Target Entity*
              </label>
              <select
                id="target"
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                required
                className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="">Select Target</option>
                {nodes.map((node) => (
                  <option key={`target-${node.id}`} value={node.id} disabled={node.id === source}>
                    {node.name} ({node.type})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">
                Relationship Type*
              </label>
              <select
                id="type"
                value={type}
                onChange={(e) => setType(e.target.value as RelationshipType)}
                required
                className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              >
                <option value="employment">Employment</option>
                <option value="founder">Founder</option>
                <option value="board_member">Board Member</option>
                <option value="investor">Investor</option>
                <option value="advisor">Advisor</option>
                <option value="parent_company">Parent Company</option>
                <option value="subsidiary">Subsidiary</option>
                <option value="partnership">Partnership</option>
                <option value="competitor">Competitor</option>
                <option value="mentor">Mentor</option>
                <option value="business_partner">Business Partner</option>
                <option value="colleague">Colleague</option>
                <option value="reports_to">Reports To</option>
              </select>
            </div>

            <div>
              <label htmlFor="year" className="block text-sm font-medium text-gray-700 mb-1">
                Year
              </label>
              <input
                id="year"
                type="number"
                min="1800"
                max={new Date().getFullYear()}
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                placeholder="e.g. 2020"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-medium text-gray-700">
                  Additional Details
                </label>
                <button
                  type="button"
                  onClick={addDetailField}
                  className="text-sm text-blue-600 hover:text-blue-800"
                >
                  + Add Detail
                </button>
              </div>

              <div className="space-y-2">
                {Object.entries(details).map(([key, value], index) => (
                  <div key={index} className="flex gap-2">
                    <input
                      type="text"
                      value={key}
                      onChange={(e) => updateDetailKey(key, e.target.value)}
                      placeholder="Detail name"
                      className="w-1/2 rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    <input
                      type="text"
                      value={value}
                      onChange={(e) => updateDetailValue(key, e.target.value)}
                      placeholder="Detail value"
                      className="w-1/2 rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    <button
                      type="button"
                      onClick={() => removeDetailField(key)}
                      className="text-red-500 hover:text-red-700"
                    >
                      &times;
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex justify-between gap-2 pt-2">
            {/* Delete button - only show if we're editing an existing relationship */}
            {relationship && onDelete && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center rounded-md border border-red-300 bg-white px-4 py-2 text-sm font-medium text-red-700 shadow-sm hover:bg-red-50"
              >
                <FaTrash className="mr-2 h-4 w-4" />
                Delete
              </button>
            )}
            <div className="flex gap-2 ml-auto">
              <button
                type="button"
                onClick={onCancel}
                className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="rounded-md bg-red-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <FaTrash className="h-5 w-5 text-red-400" aria-hidden="true" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Delete Confirmation</h3>
                <div className="mt-2 text-sm text-red-700">
                  <p>
                    Are you sure you want to delete the relationship between{' '}
                    <strong>{getNodeName(relationship?.source || '')}</strong> and{' '}
                    <strong>{getNodeName(relationship?.target || '')}</strong>?
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowDeleteConfirm(false)}
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="rounded-md bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
