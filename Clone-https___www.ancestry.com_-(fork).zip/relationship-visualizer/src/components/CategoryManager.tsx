import { useState, useEffect } from 'react';
import { FaTags, FaFilter, FaPlus } from 'react-icons/fa';
import { Node } from '../types';

interface CategoryManagerProps {
  nodes: Node[];
  onUpdateNodeCategory: (nodeId: string, category: string) => void;
  onFilterByCategory: (category: string | null) => void;
}

export default function CategoryManager({
  nodes,
  onUpdateNodeCategory,
  onFilterByCategory
}: CategoryManagerProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [categories, setCategories] = useState<{name: string; count: number}[]>([]);
  const [newCategory, setNewCategory] = useState('');
  const [selectedNode, setSelectedNode] = useState<string>('');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  // Extract categories from nodes
  useEffect(() => {
    const categoryMap: Record<string, number> = {};

    nodes.forEach(node => {
      if (node.category) {
        if (!categoryMap[node.category]) {
          categoryMap[node.category] = 0;
        }
        categoryMap[node.category]++;
      }
    });

    const categoriesList = Object.entries(categoryMap)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => a.name.localeCompare(b.name));

    setCategories(categoriesList);
  }, [nodes]);

  // Handle assigning a category to a node
  const handleAssignCategory = () => {
    if (selectedNode && newCategory.trim()) {
      onUpdateNodeCategory(selectedNode, newCategory.trim());
      setNewCategory('');
      setSelectedNode('');
    }
  };

  // Handle filter selection
  const handleFilterSelect = (category: string | null) => {
    // If clicking on the already active filter, clear it
    const newFilter = category === activeFilter ? null : category;
    setActiveFilter(newFilter);
    onFilterByCategory(newFilter);
  };

  if (!isExpanded) {
    return (
      <button
        onClick={() => setIsExpanded(true)}
        className="fixed bottom-24 left-6 bg-green-600 text-white p-3 rounded-full shadow-lg hover:bg-green-700 transition-colors z-10"
        title="Manage Categories"
      >
        <FaTags className="h-5 w-5" />
      </button>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 w-80 max-h-[90vh] overflow-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800 flex items-center">
          <FaTags className="mr-2 text-green-600" />
          Categories
        </h2>
        <button
          onClick={() => setIsExpanded(false)}
          className="text-gray-500 hover:text-gray-700"
          title="Close Categories"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Current Categories & Filtering */}
      {categories.length > 0 ? (
        <div className="mb-6">
          <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center">
            <FaFilter className="mr-2 text-green-600" /> Filter by Category
          </h3>
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category.name}
                onClick={() => handleFilterSelect(category.name)}
                className={`px-2 py-1 text-xs rounded-full flex items-center ${
                  activeFilter === category.name
                    ? 'bg-green-600 text-white'
                    : 'bg-green-100 text-green-800 hover:bg-green-200'
                }`}
              >
                {category.name}
                <span className="ml-1 px-1.5 py-0.5 text-xs rounded-full bg-white bg-opacity-20">
                  {category.count}
                </span>
              </button>
            ))}

            {/* Clear filter button */}
            {activeFilter && (
              <button
                onClick={() => handleFilterSelect(null)}
                className="px-2 py-1 text-xs rounded-full bg-gray-200 text-gray-700 hover:bg-gray-300"
              >
                Clear filter
              </button>
            )}
          </div>
        </div>
      ) : (
        <p className="text-sm text-gray-500 mb-4">No categories have been created yet.</p>
      )}

      {/* Assign Category Form */}
      <div className="bg-gray-50 p-3 rounded-lg">
        <h3 className="text-sm font-medium text-gray-700 mb-3">Assign Category to Entity</h3>

        <div className="space-y-3">
          <div>
            <label htmlFor="node-select" className="block text-xs text-gray-500 mb-1">
              Select Entity
            </label>
            <select
              id="node-select"
              value={selectedNode}
              onChange={(e) => setSelectedNode(e.target.value)}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500"
            >
              <option value="">Select an entity...</option>
              {nodes.map(node => (
                <option key={node.id} value={node.id}>
                  {node.name} {node.category ? `(${node.category})` : ''}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="category-input" className="block text-xs text-gray-500 mb-1">
              Category Name
            </label>
            <div className="flex">
              <input
                id="category-input"
                type="text"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Enter category name"
                list="existing-categories"
                className="flex-1 rounded-l-md border border-gray-300 px-3 py-2 text-sm shadow-sm focus:border-green-500 focus:outline-none focus:ring-1 focus:ring-green-500"
              />
              <datalist id="existing-categories">
                {categories.map(cat => (
                  <option key={cat.name} value={cat.name} />
                ))}
              </datalist>
              <button
                onClick={handleAssignCategory}
                disabled={!selectedNode || !newCategory.trim()}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-r-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <FaPlus className="mr-1" /> Assign
              </button>
            </div>
          </div>
        </div>

        <div className="mt-4 text-xs text-gray-500">
          <p className="font-medium">Tips:</p>
          <ul className="list-disc pl-4 mt-1 space-y-1">
            <li>Use categories to group related entities</li>
            <li>Entities with the same category will share the same color</li>
            <li>Filter by category to focus on specific groups</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
