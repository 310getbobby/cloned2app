import { useState } from 'react';
import { FaDownload, FaUpload, FaTrash, FaInfoCircle } from 'react-icons/fa';
import { GraphData } from '../types';
import Modal from './Modal';

interface DataControlsProps {
  data: GraphData;
  onReset: () => void;
  onImport: (data: GraphData) => void;
  isPersisted: boolean;
}

export default function DataControls({ data, onReset, onImport, isPersisted }: DataControlsProps) {
  const [showResetConfirmation, setShowResetConfirmation] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  // Export data as JSON file
  const handleExportData = () => {
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);

    const link = document.createElement('a');
    link.href = url;
    link.download = 'relationship-visualizer-data.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Import data from JSON file
  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedData = JSON.parse(e.target?.result as string) as GraphData;

        // Validate imported data has the correct structure
        if (!importedData.nodes || !importedData.relationships) {
          alert('Invalid data format. Import failed.');
          return;
        }

        onImport(importedData);
      } catch (error) {
        console.error('Error importing data:', error);
        alert('Failed to import data. Please check the file format.');
      }
    };
    reader.readAsText(file);

    // Reset the input value so the same file can be imported again if needed
    event.target.value = '';
  };

  return (
    <>
      {/* Data persistence status and controls */}
      <div className="flex flex-col sm:flex-row items-center gap-2">
        <div
          className="flex items-center gap-1 bg-blue-50 text-blue-800 px-3 py-1 rounded-md text-xs cursor-pointer hover:bg-blue-100"
          onClick={() => setShowInfo(true)}
          title="Click for more information"
        >
          {isPersisted ? "✓ Changes automatically saved" : "Using sample data"}
          <FaInfoCircle className="h-3 w-3 text-blue-500" />
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setShowResetConfirmation(true)}
            className="bg-red-100 text-red-700 p-2 rounded hover:bg-red-200 transition-colors"
            title="Reset to sample data"
          >
            <FaTrash className="h-4 w-4" />
          </button>
          <button
            onClick={handleExportData}
            className="bg-gray-100 text-gray-700 p-2 rounded hover:bg-gray-200 transition-colors"
            title="Export data as JSON"
          >
            <FaDownload className="h-4 w-4" />
          </button>
          <label className="bg-gray-100 text-gray-700 p-2 rounded hover:bg-gray-200 transition-colors cursor-pointer">
            <FaUpload className="h-4 w-4" />
            <input
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleImportData}
              title="Import data from JSON"
            />
          </label>
        </div>
      </div>

      {/* Reset confirmation modal */}
      <Modal
        isOpen={showResetConfirmation}
        onClose={() => setShowResetConfirmation(false)}
        title="Reset Data"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            Are you sure you want to reset to the sample data? This will replace all your current data and cannot be undone.
          </p>
          <div className="flex justify-end gap-2">
            <button
              onClick={() => setShowResetConfirmation(false)}
              className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={() => {
                onReset();
                setShowResetConfirmation(false);
              }}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
            >
              Reset Data
            </button>
          </div>
        </div>
      </Modal>

      {/* Data persistence info modal */}
      <Modal
        isOpen={showInfo}
        onClose={() => setShowInfo(false)}
        title="Data Persistence Information"
        size="md"
      >
        <div className="space-y-4">
          <p className="text-gray-700">
            This application uses your browser's localStorage to automatically save your changes.
            Here's what you need to know:
          </p>

          <ul className="list-disc pl-5 space-y-2 text-gray-700">
            <li>
              <strong>Automatic Saving:</strong> All changes you make to entities and relationships
              are automatically saved in your browser.
            </li>
            <li>
              <strong>Browser Specific:</strong> Your data is tied to this browser and device.
              If you switch browsers or devices, you won't see your saved data.
            </li>
            <li>
              <strong>Export/Import:</strong> To use your data on other devices or to back it up,
              use the export function to download your data as a JSON file, then import it elsewhere.
            </li>
            <li>
              <strong>Clearing Data:</strong> Clearing your browser cache or localStorage will remove your saved data.
            </li>
          </ul>

          <div className="flex justify-end">
            <button
              onClick={() => setShowInfo(false)}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              Got it
            </button>
          </div>
        </div>
      </Modal>
    </>
  );
}
