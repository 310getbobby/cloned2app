import { useCallback, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { GraphData, Node, Relationship, RelationshipType, NodeType, LayoutType } from '../types';

// Define colors for different relationship types
const RELATIONSHIP_COLORS: Record<RelationshipType, string> = {
  employment: '#789da8',
  founder: '#a83e6c',
  board_member: '#cfbf3c',
  investor: '#6c6463',
  advisor: '#3d3b3b',
  parent_company: '#5f7596',
  subsidiary: '#405f5b',
  partnership: '#c4acaf',
  competitor: '#364462',
  mentor: '#789da8',
  business_partner: '#a83e6c',
  colleague: '#cfbf3c',
  reports_to: '#6c6463'
};

// Define colors for node types
const NODE_COLORS: Record<NodeType, string> = {
  person: '#5f7596',
  company: '#405f5b'
};

// Category colors (used for grouping)
const CATEGORY_COLORS = [
  '#3366cc', '#dc3912', '#ff9900', '#109618', '#990099',
  '#0099c6', '#dd4477', '#66aa00', '#b82e2e', '#316395',
  '#3366cc', '#994499', '#22aa99', '#aaaa11', '#6633cc',
  '#e67300', '#8b0707', '#651067', '#329262', '#5574a6'
];

interface RelationshipGraphProps {
  data: GraphData;
  width?: number;
  height?: number;
  layout?: LayoutType;
  onNodeSelect?: (nodeId: string) => void;
  onRelationshipSelect?: (sourceId: string, targetId: string) => void;
}

// Extended node type for D3 simulation
interface D3Node extends Node, d3.SimulationNodeDatum {
  x?: number;
  y?: number;
  fx?: number | null;
  fy?: number | null;
  radius?: number;
  color?: string;
  depth?: number;
}

// Extended link type for D3 simulation
interface D3Link extends d3.SimulationLinkDatum<D3Node> {
  source: string | D3Node;
  target: string | D3Node;
  type: RelationshipType;
  year?: number;
  details?: Record<string, unknown>;
}

export default function RelationshipGraph({
  data,
  width = 960,
  height = 600,
  layout = 'force-directed',
  onNodeSelect,
  onRelationshipSelect
}: RelationshipGraphProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  // Convert our data to a format compatible with D3 force layout
  const formatData = useCallback((graphData: GraphData) => {
    const nodes: D3Node[] = graphData.nodes.map(node => ({
      ...node,
      radius: 30, // Default node radius
      color: node.category
        ? CATEGORY_COLORS[Math.abs(node.category.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)) % CATEGORY_COLORS.length]
        : NODE_COLORS[node.type]
    }));

    const links: D3Link[] = graphData.relationships.map(rel => ({
      source: rel.source,
      target: rel.target,
      type: rel.type,
      year: rel.year,
      details: rel.details
    }));

    return { nodes, links };
  }, []);

  // Apply a force-directed layout
  const applyForceDirectedLayout = useCallback((nodes: D3Node[], links: D3Link[], graph: d3.Selection<SVGGElement, unknown, null, undefined>) => {
    // Create force simulation
    const simulation = d3.forceSimulation<D3Node>(nodes)
      .force('link', d3.forceLink<D3Node, D3Link>(links).id(d => d.id).distance(150))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collide', d3.forceCollide(70));

    // Update positions on each tick of the simulation
    simulation.on('tick', () => {
      // Update link positions
      graph.selectAll<SVGLineElement, D3Link>('line.link')
        .attr('x1', d => (typeof d.source === 'object' ? d.source.x || 0 : 0))
        .attr('y1', d => (typeof d.source === 'object' ? d.source.y || 0 : 0))
        .attr('x2', d => (typeof d.target === 'object' ? d.target.x || 0 : 0))
        .attr('y2', d => (typeof d.target === 'object' ? d.target.y || 0 : 0));

      // Update node positions
      graph.selectAll<SVGGElement, D3Node>('g.node')
        .attr('transform', d => `translate(${(d.x || 0) - 75}, ${(d.y || 0) - 30})`);
    });

    return simulation;
  }, [width, height]);

  // Apply a circular layout
  const applyCircularLayout = useCallback((nodes: D3Node[], links: D3Link[], graph: d3.Selection<SVGGElement, unknown, null, undefined>) => {
    const radius = Math.min(width, height) / 2 - 150;
    const angleStep = (2 * Math.PI) / nodes.length;

    // Position nodes in a circle
    nodes.forEach((node, i) => {
      const angle = i * angleStep;
      node.x = width / 2 + radius * Math.cos(angle);
      node.y = height / 2 + radius * Math.sin(angle);
      node.fx = node.x; // Fix the position
      node.fy = node.y;
    });

    // Create a gentle force simulation just to handle the links
    const simulation = d3.forceSimulation<D3Node>(nodes)
      .force('link', d3.forceLink<D3Node, D3Link>(links).id(d => d.id).distance(150).strength(0.1))
      .alphaDecay(0.1);

    // Update positions on each tick of the simulation
    simulation.on('tick', () => {
      // Update link positions
      graph.selectAll<SVGLineElement, D3Link>('line.link')
        .attr('x1', d => (typeof d.source === 'object' ? d.source.fx || d.source.x || 0 : 0))
        .attr('y1', d => (typeof d.source === 'object' ? d.source.fy || d.source.y || 0 : 0))
        .attr('x2', d => (typeof d.target === 'object' ? d.target.fx || d.target.x || 0 : 0))
        .attr('y2', d => (typeof d.target === 'object' ? d.target.fy || d.target.y || 0 : 0));

      // Update node positions
      graph.selectAll<SVGGElement, D3Node>('g.node')
        .attr('transform', d => `translate(${((d.fx || d.x || 0)) - 75}, ${((d.fy || d.y || 0)) - 30})`);
    });

    return simulation;
  }, [width, height]);

  // Apply a hierarchical layout
  const applyHierarchicalLayout = useCallback((nodes: D3Node[], links: D3Link[], graph: d3.Selection<SVGGElement, unknown, null, undefined>) => {
    // First, we need to find the root nodes (nodes with only outgoing connections)
    const targetNodes = new Set(links.map(l => typeof l.target === 'string' ? l.target : l.target.id));
    let rootNodes = nodes.filter(n => !targetNodes.has(n.id));

    // If no root nodes found, take the first node as root
    if (rootNodes.length === 0 && nodes.length > 0) {
      rootNodes = [nodes[0]];
    }

    // Assign depths to nodes
    const assignDepths = (nodeId: string, depth: number, visited: Set<string>) => {
      if (visited.has(nodeId)) return;
      visited.add(nodeId);

      const node = nodes.find(n => n.id === nodeId);
      if (node) {
        node.depth = depth;

        // Find all connections from this node
        links.forEach(link => {
          const sourceId = typeof link.source === 'string' ? link.source : link.source.id;
          const targetId = typeof link.target === 'string' ? link.target : link.target.id;

          if (sourceId === nodeId) {
            assignDepths(targetId, depth + 1, visited);
          }
        });
      }
    };

    const visited = new Set<string>();
    rootNodes.forEach(root => assignDepths(root.id, 0, visited));

    // Count nodes at each depth to position them horizontally
    const nodesByDepth: Record<number, D3Node[]> = {};
    nodes.forEach(node => {
      const depth = node.depth !== undefined ? node.depth : 0;
      if (!nodesByDepth[depth]) {
        nodesByDepth[depth] = [];
      }
      nodesByDepth[depth].push(node);
    });

    // Position nodes based on their depth
    const depthLevels = Object.keys(nodesByDepth).map(Number);
    const maxDepth = Math.max(...depthLevels);
    const verticalSpacing = height / (maxDepth + 2);

    depthLevels.forEach(depth => {
      const nodesAtDepth = nodesByDepth[depth];
      const horizontalSpacing = width / (nodesAtDepth.length + 1);

      nodesAtDepth.forEach((node, i) => {
        node.x = horizontalSpacing * (i + 1);
        node.y = verticalSpacing * (depth + 1);
        node.fx = node.x;
        node.fy = node.y;
      });
    });

    // Create a gentle force simulation just to handle the links
    const simulation = d3.forceSimulation<D3Node>(nodes)
      .force('link', d3.forceLink<D3Node, D3Link>(links).id(d => d.id).distance(150).strength(0.1))
      .alphaDecay(0.1);

    // Update positions on each tick of the simulation
    simulation.on('tick', () => {
      // Update link positions
      graph.selectAll<SVGLineElement, D3Link>('line.link')
        .attr('x1', d => (typeof d.source === 'object' ? d.source.fx || d.source.x || 0 : 0))
        .attr('y1', d => (typeof d.source === 'object' ? d.source.fy || d.source.y || 0 : 0))
        .attr('x2', d => (typeof d.target === 'object' ? d.target.fx || d.target.x || 0 : 0))
        .attr('y2', d => (typeof d.target === 'object' ? d.target.fy || d.target.y || 0 : 0));

      // Update node positions
      graph.selectAll<SVGGElement, D3Node>('g.node')
        .attr('transform', d => `translate(${((d.fx || d.x || 0)) - 75}, ${((d.fy || d.y || 0)) - 30})`);
    });

    return simulation;
  }, [width, height]);

  // Apply a radial layout
  const applyRadialLayout = useCallback((nodes: D3Node[], links: D3Link[], graph: d3.Selection<SVGGElement, unknown, null, undefined>) => {
    // First, we need to find a central node
    // We'll use the node with the most connections
    const nodeConnections: Record<string, number> = {};
    links.forEach(link => {
      const sourceId = typeof link.source === 'string' ? link.source : link.source.id;
      const targetId = typeof link.target === 'string' ? link.target : link.target.id;

      if (!nodeConnections[sourceId]) nodeConnections[sourceId] = 0;
      if (!nodeConnections[targetId]) nodeConnections[targetId] = 0;

      nodeConnections[sourceId]++;
      nodeConnections[targetId]++;
    });

    let centralNodeId = nodes[0]?.id;
    let maxConnections = 0;

    Object.entries(nodeConnections).forEach(([id, count]) => {
      if (count > maxConnections) {
        maxConnections = count;
        centralNodeId = id;
      }
    });

    // Position central node in the middle
    const centralNode = nodes.find(n => n.id === centralNodeId);
    if (centralNode) {
      centralNode.x = width / 2;
      centralNode.y = height / 2;
      centralNode.fx = centralNode.x;
      centralNode.fy = centralNode.y;
    }

    // Create a force simulation with a radial force
    const simulation = d3.forceSimulation<D3Node>(nodes)
      .force('link', d3.forceLink<D3Node, D3Link>(links).id(d => d.id).distance(150))
      .force('charge', d3.forceManyBody().strength(-300))
      .force('radial', d3.forceRadial(Math.min(width, height) / 3, width / 2, height / 2))
      .force('collide', d3.forceCollide(70));

    // Update positions on each tick of the simulation
    simulation.on('tick', () => {
      // Update link positions
      graph.selectAll<SVGLineElement, D3Link>('line.link')
        .attr('x1', d => (typeof d.source === 'object' ? d.source.x || 0 : 0))
        .attr('y1', d => (typeof d.source === 'object' ? d.source.y || 0 : 0))
        .attr('x2', d => (typeof d.target === 'object' ? d.target.x || 0 : 0))
        .attr('y2', d => (typeof d.target === 'object' ? d.target.y || 0 : 0));

      // Update node positions
      graph.selectAll<SVGGElement, D3Node>('g.node')
        .attr('transform', d => `translate(${(d.x || 0) - 75}, ${(d.y || 0) - 30})`);
    });

    return simulation;
  }, [width, height]);

  // Create the visualization
  const createVisualization = useCallback(() => {
    if (!svgRef.current) return;

    // Clear any existing visualization
    d3.select(svgRef.current).selectAll('*').remove();

    const svg = d3.select(svgRef.current)
      .attr('viewBox', `0 0 ${width} ${height}`)
      .attr('width', width)
      .attr('height', height);

    // Add a container for the graph
    const graph = svg.append('g')
      .attr('class', 'graph-container');

    // Create a zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on('zoom', (event: d3.D3ZoomEvent<SVGSVGElement, unknown>) => {
        graph.attr('transform', event.transform.toString());
      });

    // Apply zoom behavior to svg
    svg.call(zoom);

    // Format our data for D3
    const { nodes, links } = formatData(data);

    // Create the links
    const link = graph.append('g')
      .attr('class', 'links')
      .selectAll('line')
      .data<D3Link>(links)
      .enter()
      .append('line')
      .attr('class', 'link')
      .attr('stroke', (d) => {
        return RELATIONSHIP_COLORS[d.type as RelationshipType] || '#999';
      })
      .attr('stroke-width', 2)
      .attr('stroke-opacity', 0.6)
      .attr('stroke-dasharray', (d) => d.type === 'founder' ? '5,5' : null)
      .style('cursor', onRelationshipSelect ? 'pointer' : 'default')
      .on('click', function(event: MouseEvent, d: D3Link) {
        if (onRelationshipSelect) {
          event.stopPropagation();
          const sourceId = typeof d.source === 'string' ? d.source : d.source.id;
          const targetId = typeof d.target === 'string' ? d.target : d.target.id;
          onRelationshipSelect(sourceId, targetId);
        }
      });

    // Create the nodes
    const node = graph.append('g')
      .attr('class', 'nodes')
      .selectAll('.node')
      .data<D3Node>(nodes)
      .enter()
      .append('g')
      .attr('class', 'node')
      .style('cursor', onNodeSelect ? 'pointer' : 'default')
      .on('click', function(event: MouseEvent, d: D3Node) {
        if (onNodeSelect) {
          event.stopPropagation();
          onNodeSelect(d.id);
        }
      })
      .call(d3.drag<SVGGElement, D3Node>()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended)
      );

    // Add rectangles for the node backgrounds
    node.append('rect')
      .attr('width', 150)
      .attr('height', 60)
      .attr('rx', 5)
      .attr('ry', 5)
      .attr('fill', (d) => {
        return d.color || NODE_COLORS[d.type] || '#999';
      })
      .attr('stroke', '#fff')
      .attr('stroke-width', 1.5);

    // Add images to the nodes
    node.append('image')
      .attr('x', 5)
      .attr('y', 5)
      .attr('width', 50)
      .attr('height', 50)
      .attr('href', (d) => d.image || (d.type === 'person'
        ? 'https://randomuser.me/api/portraits/lego/1.jpg'
        : 'https://placehold.co/400x400/364462/white?text=CO'));

    // Add the node name
    node.append('text')
      .attr('x', 60)
      .attr('y', 20)
      .attr('fill', '#fff')
      .attr('font-weight', 'bold')
      .text((d) => d.name?.length > 18 ? `${d.name.substring(0, 16)}...` : d.name);

    // Add the node type/title
    node.append('text')
      .attr('x', 60)
      .attr('y', 40)
      .attr('fill', '#fff')
      .attr('font-size', '12px')
      .text((d) => (d.type === 'person' ? d.title : d.industry) || d.type);

    // Add tooltip div
    const tooltip = d3.select('body').append('div')
      .attr('class', 'tooltip')
      .style('position', 'absolute')
      .style('visibility', 'hidden')
      .style('background-color', 'rgba(0, 0, 0, 0.8)')
      .style('color', 'white')
      .style('padding', '8px')
      .style('border-radius', '4px')
      .style('font-size', '12px')
      .style('max-width', '300px')
      .style('z-index', '10');

    // Add event handlers for nodes
    node.on('mouseover', function(event: MouseEvent, d: D3Node) {
      // Show tooltip
      tooltip.style('visibility', 'visible')
        .html(() => {
          let content = `<div><strong>${d.name}</strong></div>`;

          if (d.type === 'person') {
            content += `<div>${d.title || ''}</div>`;
            if (d.details) {
              content += d.details.education ? `<div>${d.details.education}</div>` : '';
              content += d.details.location ? `<div>${d.details.location}</div>` : '';
              content += d.details.age ? `<div>Age: ${d.details.age}</div>` : '';
            }
          } else if (d.type === 'company') {
            content += `<div>${d.industry || ''}</div>`;
            if (d.details) {
              content += d.details.founded ? `<div>Founded: ${d.details.founded}</div>` : '';
              content += d.details.headquarters ? `<div>${d.details.headquarters}</div>` : '';
              content += d.details.employees ? `<div>Employees: ${d.details.employees}</div>` : '';
            }
          }

          if (d.category) {
            content += `<div class="mt-1">Category: ${d.category}</div>`;
          }

          return content;
        });
    })
    .on('mousemove', function(event: MouseEvent) {
      tooltip
        .style('top', (event.pageY - 10) + 'px')
        .style('left', (event.pageX + 10) + 'px');
    })
    .on('mouseout', function() {
      tooltip.style('visibility', 'hidden');
    });

    // Add event handlers for links
    link.on('mouseover', function(event: MouseEvent, d: D3Link) {
      // Show tooltip for relationship
      tooltip.style('visibility', 'visible')
        .html(() => {
          const sourceNode = nodes.find((n) => n.id === (typeof d.source === 'string' ? d.source : d.source.id));
          const targetNode = nodes.find((n) => n.id === (typeof d.target === 'string' ? d.target : d.target.id));

          let content = `<div><strong>${sourceNode?.name} → ${targetNode?.name}</strong></div>`;
          content += `<div>Relationship: ${d.type.replace('_', ' ')}</div>`;

          if (d.year) {
            content += `<div>Since: ${d.year}</div>`;
          }

          if (d.details) {
            Object.entries(d.details).forEach(([key, value]) => {
              content += `<div>${key.replace('_', ' ')}: ${value}</div>`;
            });
          }

          return content;
        });
    })
    .on('mousemove', function(event: MouseEvent) {
      tooltip
        .style('top', (event.pageY - 10) + 'px')
        .style('left', (event.pageX + 10) + 'px');
    })
    .on('mouseout', function() {
      tooltip.style('visibility', 'hidden');
    });

    // Apply the selected layout
    let simulation: d3.Simulation<D3Node, undefined>;

    switch (layout) {
      case 'circular':
        simulation = applyCircularLayout(nodes, links, graph);
        break;
      case 'hierarchical':
        simulation = applyHierarchicalLayout(nodes, links, graph);
        break;
      case 'radial':
        simulation = applyRadialLayout(nodes, links, graph);
        break;
      case 'force-directed':
      default:
        simulation = applyForceDirectedLayout(nodes, links, graph);
        break;
    }

    // Drag functions
    function dragstarted(event: d3.D3DragEvent<SVGGElement, D3Node, D3Node>, d: D3Node) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      d.fx = d.x;
      d.fy = d.y;
    }

    function dragged(event: d3.D3DragEvent<SVGGElement, D3Node, D3Node>, d: D3Node) {
      d.fx = event.x;
      d.fy = event.y;
    }

    function dragended(event: d3.D3DragEvent<SVGGElement, D3Node, D3Node>, d: D3Node) {
      if (!event.active) simulation.alphaTarget(0);

      // Only release fixed position in force-directed layout
      if (layout === 'force-directed') {
        d.fx = null;
        d.fy = null;
      }
    }

    // Return cleanup function
    return () => {
      simulation.stop();
      tooltip.remove();
    };
  }, [
    data,
    formatData,
    width,
    height,
    layout,
    onNodeSelect,
    onRelationshipSelect,
    applyForceDirectedLayout,
    applyCircularLayout,
    applyHierarchicalLayout,
    applyRadialLayout
  ]);

  useEffect(() => {
    const cleanup = createVisualization();
    return cleanup;
  }, [createVisualization]);

  return (
    <div className="relationship-graph-container w-full h-full">
      <svg
        ref={svgRef}
        className="relationship-graph w-full h-full"
        style={{ maxHeight: '100%', maxWidth: '100%' }}
      />
    </div>
  );
}
