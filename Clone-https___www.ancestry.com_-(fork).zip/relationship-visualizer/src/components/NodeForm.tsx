import { useState, useEffect } from 'react';
import { Node, NodeType } from '../types';
import { FaTrash } from 'react-icons/fa';

interface NodeFormProps {
  node?: Node;
  onSave: (node: Node) => void;
  onDelete?: (nodeId: string) => void;
  onCancel: () => void;
}

export default function NodeForm({ node, onSave, onDelete, onCancel }: NodeFormProps) {
  const [nodeType, setNodeType] = useState<NodeType>(node?.type || 'person');
  const [name, setName] = useState(node?.name || '');
  const [image, setImage] = useState(node?.image || '');
  const [title, setTitle] = useState(node?.title || '');
  const [industry, setIndustry] = useState(node?.industry || '');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Details fields
  const [age, setAge] = useState(node?.details?.age?.toString() || '');
  const [location, setLocation] = useState(node?.details?.location?.toString() || '');
  const [education, setEducation] = useState(node?.details?.education?.toString() || '');
  const [founded, setFounded] = useState(node?.details?.founded?.toString() || '');
  const [headquarters, setHeadquarters] = useState(node?.details?.headquarters?.toString() || '');
  const [employees, setEmployees] = useState(node?.details?.employees?.toString() || '');

  // Update form when node changes
  useEffect(() => {
    if (node) {
      setNodeType(node.type);
      setName(node.name);
      setImage(node.image || '');
      setTitle(node.title || '');
      setIndustry(node.industry || '');

      setAge(node.details?.age?.toString() || '');
      setLocation(node.details?.location?.toString() || '');
      setEducation(node.details?.education?.toString() || '');
      setFounded(node.details?.founded?.toString() || '');
      setHeadquarters(node.details?.headquarters?.toString() || '');
      setEmployees(node.details?.employees?.toString() || '');
    }
  }, [node]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Create details object based on node type
    const details: Record<string, unknown> = {};

    if (nodeType === 'person') {
      if (age) details.age = parseInt(age, 10);
      if (location) details.location = location;
      if (education) details.education = education;
    } else if (nodeType === 'company') {
      if (founded) details.founded = parseInt(founded, 10);
      if (headquarters) details.headquarters = headquarters;
      if (employees) details.employees = parseInt(employees, 10);
    }

    // Create the node object
    const newNode: Node = {
      id: node?.id || `${nodeType}${Date.now()}`,
      type: nodeType,
      name,
      ...(image ? { image } : {}),
      ...(nodeType === 'person' ? { title } : {}),
      ...(nodeType === 'company' ? { industry } : {}),
      details: Object.keys(details).length > 0 ? details : undefined,
    };

    onSave(newNode);
  };

  const handleDelete = () => {
    if (onDelete && node) {
      onDelete(node.id);
    }
  };

  return (
    <div>
      {!showDeleteConfirm ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Entity Type
              </label>
              <div className="flex gap-4">
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="nodeType"
                    value="person"
                    checked={nodeType === 'person'}
                    onChange={() => setNodeType('person')}
                    className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                  />
                  <span className="ml-2">Person</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="radio"
                    name="nodeType"
                    value="company"
                    checked={nodeType === 'company'}
                    onChange={() => setNodeType('company')}
                    className="h-4 w-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                  />
                  <span className="ml-2">Company</span>
                </label>
              </div>
            </div>

            <div className="col-span-2">
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Name*
              </label>
              <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div className="col-span-2">
              <label htmlFor="image" className="block text-sm font-medium text-gray-700 mb-1">
                Image URL
              </label>
              <input
                id="image"
                type="text"
                value={image}
                onChange={(e) => setImage(e.target.value)}
                placeholder="https://example.com/image.jpg"
                className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            {nodeType === 'person' ? (
              <>
                <div className="col-span-2">
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                    Title
                  </label>
                  <input
                    id="title"
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="CEO, Developer, etc."
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">
                    Age
                  </label>
                  <input
                    id="age"
                    type="number"
                    min="0"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                    Location
                  </label>
                  <input
                    id="location"
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="col-span-2">
                  <label htmlFor="education" className="block text-sm font-medium text-gray-700 mb-1">
                    Education
                  </label>
                  <input
                    id="education"
                    type="text"
                    value={education}
                    onChange={(e) => setEducation(e.target.value)}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </>
            ) : (
              <>
                <div className="col-span-2">
                  <label htmlFor="industry" className="block text-sm font-medium text-gray-700 mb-1">
                    Industry
                  </label>
                  <input
                    id="industry"
                    type="text"
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                    placeholder="Technology, Finance, etc."
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="founded" className="block text-sm font-medium text-gray-700 mb-1">
                    Founded Year
                  </label>
                  <input
                    id="founded"
                    type="number"
                    min="1800"
                    max={new Date().getFullYear()}
                    value={founded}
                    onChange={(e) => setFounded(e.target.value)}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="employees" className="block text-sm font-medium text-gray-700 mb-1">
                    Number of Employees
                  </label>
                  <input
                    id="employees"
                    type="number"
                    min="1"
                    value={employees}
                    onChange={(e) => setEmployees(e.target.value)}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="col-span-2">
                  <label htmlFor="headquarters" className="block text-sm font-medium text-gray-700 mb-1">
                    Headquarters
                  </label>
                  <input
                    id="headquarters"
                    type="text"
                    value={headquarters}
                    onChange={(e) => setHeadquarters(e.target.value)}
                    className="w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </>
            )}
          </div>

          <div className="flex justify-between gap-2 pt-2">
            {/* Delete button - only show if we're editing an existing node */}
            {node && onDelete && (
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="flex items-center rounded-md border border-red-300 bg-white px-4 py-2 text-sm font-medium text-red-700 shadow-sm hover:bg-red-50"
              >
                <FaTrash className="mr-2 h-4 w-4" />
                Delete
              </button>
            )}
            <div className="flex gap-2 ml-auto">
              <button
                type="button"
                onClick={onCancel}
                className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700"
              >
                Save
              </button>
            </div>
          </div>
        </form>
      ) : (
        <div className="space-y-4">
          <div className="rounded-md bg-red-50 p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <FaTrash className="h-5 w-5 text-red-400" aria-hidden="true" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-red-800">Delete Confirmation</h3>
                <div className="mt-2 text-sm text-red-700">
                  <p>
                    Are you sure you want to delete {node?.name}? This will also remove all relationships connected to this entity.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowDeleteConfirm(false)}
              className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="rounded-md bg-red-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-red-700"
            >
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
