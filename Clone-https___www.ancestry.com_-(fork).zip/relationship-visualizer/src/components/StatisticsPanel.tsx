import { useMemo } from 'react';
import { GraphData, RelationshipType, NodeType } from '../types';
import { FaChartBar, FaUsers, FaBuilding, FaNetworkWired } from 'react-icons/fa';

// Type for summary stats
interface GraphStats {
  totalNodes: number;
  nodesByType: Record<NodeType, number>;
  totalRelationships: number;
  relationshipsByType: Partial<Record<RelationshipType, number>>;
  mostConnected: {
    name: string;
    id: string;
    type: NodeType;
    count: number;
  } | null;
  avgConnectionsPerNode: number;
  categories: {
    name: string;
    count: number;
  }[];
}

interface StatisticsPanelProps {
  data: GraphData;
  isOpen: boolean;
  onToggle: () => void;
}

export default function StatisticsPanel({ data, isOpen, onToggle }: StatisticsPanelProps) {
  // Calculate statistics from the graph data
  const stats = useMemo<GraphStats>(() => {
    // Count nodes by type
    const nodesByType: Record<NodeType, number> = {
      person: 0,
      company: 0
    };

    data.nodes.forEach(node => {
      nodesByType[node.type]++;
    });

    // Count relationships by type
    const relationshipsByType: Partial<Record<RelationshipType, number>> = {};
    data.relationships.forEach(rel => {
      if (!relationshipsByType[rel.type]) {
        relationshipsByType[rel.type] = 0;
      }
      relationshipsByType[rel.type]!++;
    });

    // Find the most connected node
    const connectionCounts: Record<string, number> = {};
    data.relationships.forEach(rel => {
      if (!connectionCounts[rel.source]) connectionCounts[rel.source] = 0;
      if (!connectionCounts[rel.target]) connectionCounts[rel.target] = 0;
      connectionCounts[rel.source]++;
      connectionCounts[rel.target]++;
    });

    let mostConnectedNode = null;
    let maxConnections = 0;

    Object.entries(connectionCounts).forEach(([nodeId, count]) => {
      if (count > maxConnections) {
        const node = data.nodes.find(n => n.id === nodeId);
        if (node) {
          mostConnectedNode = {
            name: node.name,
            id: node.id,
            type: node.type,
            count
          };
          maxConnections = count;
        }
      }
    });

    // Calculate average connections per node
    const avgConnectionsPerNode = data.nodes.length > 0
      ? data.relationships.length * 2 / data.nodes.length
      : 0;

    // Count categories
    const categoryCount: Record<string, number> = {};
    data.nodes.forEach(node => {
      if (node.category) {
        if (!categoryCount[node.category]) {
          categoryCount[node.category] = 0;
        }
        categoryCount[node.category]++;
      }
    });

    const categories = Object.entries(categoryCount).map(([name, count]) => ({
      name,
      count
    })).sort((a, b) => b.count - a.count);

    return {
      totalNodes: data.nodes.length,
      nodesByType,
      totalRelationships: data.relationships.length,
      relationshipsByType,
      mostConnected: mostConnectedNode,
      avgConnectionsPerNode,
      categories
    };
  }, [data]);

  if (!isOpen) {
    return (
      <button
        onClick={onToggle}
        className="fixed bottom-6 left-6 bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700 transition-colors z-10"
        title="Show Statistics"
      >
        <FaChartBar className="h-5 w-5" />
      </button>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 w-80 max-h-[90vh] overflow-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-800">Graph Statistics</h2>
        <button
          onClick={onToggle}
          className="text-gray-500 hover:text-gray-700"
          title="Close Statistics"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="space-y-4">
        {/* Nodes section */}
        <div className="bg-blue-50 p-3 rounded-lg">
          <h3 className="flex items-center text-sm font-medium text-blue-800 mb-2">
            <FaUsers className="mr-2" /> Nodes
          </h3>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-white p-2 rounded border border-blue-100">
              <p className="text-xs text-gray-500">Total</p>
              <p className="text-lg font-bold text-blue-600">{stats.totalNodes}</p>
            </div>
            <div className="bg-white p-2 rounded border border-blue-100">
              <p className="text-xs text-gray-500">People</p>
              <p className="text-lg font-bold text-blue-600">{stats.nodesByType.person}</p>
            </div>
            <div className="bg-white p-2 rounded border border-blue-100">
              <p className="text-xs text-gray-500">Companies</p>
              <p className="text-lg font-bold text-blue-600">{stats.nodesByType.company}</p>
            </div>
            <div className="bg-white p-2 rounded border border-blue-100">
              <p className="text-xs text-gray-500">Avg. Connections</p>
              <p className="text-lg font-bold text-blue-600">{stats.avgConnectionsPerNode.toFixed(1)}</p>
            </div>
          </div>
        </div>

        {/* Relationships section */}
        <div className="bg-green-50 p-3 rounded-lg">
          <h3 className="flex items-center text-sm font-medium text-green-800 mb-2">
            <FaNetworkWired className="mr-2" /> Relationships
          </h3>
          <div className="bg-white p-2 rounded border border-green-100 mb-2">
            <p className="text-xs text-gray-500">Total</p>
            <p className="text-lg font-bold text-green-600">{stats.totalRelationships}</p>
          </div>

          {Object.entries(stats.relationshipsByType).length > 0 && (
            <div className="space-y-1 mt-2">
              <h4 className="text-xs font-medium text-gray-600">By Type:</h4>
              <div className="text-xs bg-white rounded border border-green-100 divide-y">
                {Object.entries(stats.relationshipsByType)
                  .sort(([, countA], [, countB]) => (countB || 0) - (countA || 0))
                  .map(([type, count]) => (
                    <div key={type} className="flex justify-between items-center p-2">
                      <span className="capitalize">{type.replace(/_/g, ' ')}</span>
                      <span className="font-medium">{count}</span>
                    </div>
                  ))
                }
              </div>
            </div>
          )}
        </div>

        {/* Most connected node */}
        {stats.mostConnected && (
          <div className="bg-purple-50 p-3 rounded-lg">
            <h3 className="text-sm font-medium text-purple-800 mb-2">Most Connected Entity</h3>
            <div className="bg-white p-2 rounded border border-purple-100">
              <div className="flex items-center">
                {stats.mostConnected.type === 'person' ? (
                  <FaUsers className="text-purple-600 mr-2" />
                ) : (
                  <FaBuilding className="text-purple-600 mr-2" />
                )}
                <div>
                  <p className="font-medium">{stats.mostConnected.name}</p>
                  <p className="text-xs text-gray-500">
                    {stats.mostConnected.count} connection{stats.mostConnected.count !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Categories section */}
        {stats.categories.length > 0 && (
          <div className="bg-yellow-50 p-3 rounded-lg">
            <h3 className="text-sm font-medium text-yellow-800 mb-2">Categories</h3>
            <div className="space-y-2">
              {stats.categories.map(category => (
                <div key={category.name} className="bg-white p-2 rounded border border-yellow-100">
                  <div className="flex justify-between items-center">
                    <p className="font-medium">{category.name}</p>
                    <p className="text-sm text-gray-500">{category.count} node{category.count !== 1 ? 's' : ''}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
