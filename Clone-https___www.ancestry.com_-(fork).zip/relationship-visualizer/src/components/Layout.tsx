import React, { useState } from 'react';
import { FaSearch, FaFilter } from 'react-icons/fa';

interface LayoutProps {
  children: React.ReactNode;
  title: string;
  onSearch?: (query: string) => void;
  onFilterChange?: (filter: string) => void;
}

export default function Layout({
  children,
  title,
  onSearch,
  onFilterChange
}: LayoutProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterValue, setFilterValue] = useState('all');

  const handleSearch = () => {
    if (onSearch) {
      onSearch(searchQuery);
    }
  };

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setFilterValue(value);
    if (onFilterChange) {
      onFilterChange(value);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      <header className="bg-slate-800 text-white p-4 shadow-md">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
          <h1 className="text-2xl font-bold mb-4 md:mb-0">{title}</h1>

          <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:min-w-[300px]">
              <input
                type="text"
                placeholder="Search entities..."
                className="w-full py-2 pl-3 pr-10 rounded-md border border-slate-600 bg-slate-700 text-white placeholder-slate-400"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleSearch();
                  }
                }}
              />
              <button
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white"
                onClick={handleSearch}
              >
                <FaSearch />
              </button>
            </div>

            <div className="relative flex-1 md:w-auto md:flex-initial">
              <div className="flex items-center gap-2 bg-slate-700 py-2 px-3 rounded-md border border-slate-600">
                <FaFilter className="text-slate-400" />
                <select
                  className="bg-transparent text-white w-full appearance-none focus:outline-none"
                  value={filterValue}
                  onChange={handleFilterChange}
                >
                  <option value="all">All Relationships</option>
                  <option value="employment">Employment</option>
                  <option value="founder">Founder</option>
                  <option value="investor">Investor</option>
                  <option value="board_member">Board Member</option>
                  <option value="advisor">Advisor</option>
                  <option value="parent_company">Parent Company</option>
                  <option value="subsidiary">Subsidiary</option>
                  <option value="partnership">Partnership</option>
                  <option value="business_partner">Business Partner</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 p-4">
        <div className="container mx-auto">
          {children}
        </div>
      </main>

      <footer className="bg-slate-800 text-white p-4 text-center">
        <div className="container mx-auto">
          <p>Corporate Relationship Visualization &copy; {new Date().getFullYear()}</p>
        </div>
      </footer>
    </div>
  );
}
