// Node types
export type NodeType = 'person' | 'company';

// Relationship types
export type RelationshipType =
  | 'employment'
  | 'founder'
  | 'board_member'
  | 'investor'
  | 'advisor'
  | 'parent_company'
  | 'subsidiary'
  | 'partnership'
  | 'competitor'
  | 'mentor'
  | 'business_partner'
  | 'colleague'
  | 'reports_to';

// Layout types
export type LayoutType =
  | 'force-directed'
  | 'circular'
  | 'hierarchical'
  | 'radial';

// Node interface
export interface Node {
  id: string;
  type: NodeType;
  name: string;
  title?: string;        // For person nodes
  industry?: string;     // For company nodes
  image?: string;        // URL to image
  details?: Record<string, unknown>;
  category?: string;     // Optional category for grouping
}

// Relationship interface
export interface Relationship {
  source: string;        // Node ID
  target: string;        // Node ID
  type: RelationshipType;
  year?: number;         // Optional relationship year
  details?: Record<string, unknown>;
}

// Graph data interface
export interface GraphData {
  nodes: Node[];
  relationships: Relationship[];
}
