import { GraphData } from '../types';

export const sampleData: GraphData = {
  nodes: [
    {
      id: 'person1',
      type: 'person',
      name: 'John Smith',
      image: 'https://randomuser.me/api/portraits/men/1.jpg',
      title: 'CEO',
      details: {
        age: 45,
        location: 'San Francisco, CA',
        education: 'MBA, Stanford University'
      }
    },
    {
      id: 'person2',
      type: 'person',
      name: 'Sarah Johnson',
      image: 'https://randomuser.me/api/portraits/women/1.jpg',
      title: 'CTO',
      details: {
        age: 38,
        location: 'San Francisco, CA',
        education: 'PhD in Computer Science, MIT'
      }
    },
    {
      id: 'person3',
      type: 'person',
      name: 'Michael Zhang',
      image: 'https://randomuser.me/api/portraits/men/2.jpg',
      title: 'Lead Investor',
      details: {
        age: 52,
        location: 'New York, NY',
        education: 'MBA, Harvard Business School'
      }
    },
    {
      id: 'person4',
      type: 'person',
      name: 'Emily Chen',
      image: 'https://randomuser.me/api/portraits/women/2.jpg',
      title: 'Board Member',
      details: {
        age: 47,
        location: 'Boston, MA',
        education: 'JD, Harvard Law School'
      }
    },
    {
      id: 'company1',
      type: 'company',
      name: 'Tech Innovations Inc.',
      image: 'https://placehold.co/400x400/5f7596/white?text=TI',
      industry: 'Technology',
      details: {
        founded: 2015,
        headquarters: 'San Francisco, CA',
        employees: 250
      }
    },
    {
      id: 'company2',
      type: 'company',
      name: 'Finance Solutions LLC',
      image: 'https://placehold.co/400x400/405f5b/white?text=FS',
      industry: 'Financial Services',
      details: {
        founded: 2010,
        headquarters: 'New York, NY',
        employees: 500
      }
    },
    {
      id: 'company3',
      type: 'company',
      name: 'Global Ventures',
      image: 'https://placehold.co/400x400/a83e6c/white?text=GV',
      industry: 'Venture Capital',
      details: {
        founded: 2005,
        headquarters: 'San Francisco, CA',
        employees: 75
      }
    },
    {
      id: 'company4',
      type: 'company',
      name: 'DataTech Solutions',
      image: 'https://placehold.co/400x400/789da8/white?text=DS',
      industry: 'Big Data',
      details: {
        founded: 2018,
        headquarters: 'Austin, TX',
        employees: 120
      }
    }
  ],
  relationships: [
    {
      source: 'person1',
      target: 'company1',
      type: 'founder',
      year: 2015,
      details: {
        equity: '35%',
        position: 'CEO & Founder'
      }
    },
    {
      source: 'person2',
      target: 'company1',
      type: 'founder',
      year: 2015,
      details: {
        equity: '30%',
        position: 'CTO & Co-Founder'
      }
    },
    {
      source: 'person3',
      target: 'company3',
      type: 'employment',
      year: 2005,
      details: {
        position: 'Managing Partner'
      }
    },
    {
      source: 'company3',
      target: 'company1',
      type: 'investor',
      year: 2016,
      details: {
        investment: '$5M Series A',
        equity: '15%'
      }
    },
    {
      source: 'person4',
      target: 'company1',
      type: 'board_member',
      year: 2017,
      details: {
        position: 'Independent Board Member'
      }
    },
    {
      source: 'company1',
      target: 'company4',
      type: 'parent_company',
      year: 2020,
      details: {
        acquisition: '$50M',
        retained_leadership: true
      }
    },
    {
      source: 'company2',
      target: 'company1',
      type: 'partnership',
      year: 2018,
      details: {
        deal_type: 'Strategic Partnership',
        value: '$2M annual'
      }
    },
    {
      source: 'person1',
      target: 'person2',
      type: 'business_partner',
      year: 2014,
      details: {
        relationship: 'University classmates'
      }
    }
  ]
};
