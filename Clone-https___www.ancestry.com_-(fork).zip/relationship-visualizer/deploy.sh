#!/bin/bash
set -e

echo "Starting deployment process..."

# Install dependencies
echo "Installing dependencies..."
bun install

# Build the project
echo "Building the project..."
bun run build

# Check if build folder exists
if [ -d "build" ]; then
  echo "Build successful! Ready for deployment."
else
  echo "Build folder not found. Build may have failed."
  exit 1
fi

echo "Deployment preparation complete!"
